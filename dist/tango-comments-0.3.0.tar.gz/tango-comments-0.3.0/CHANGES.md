# Tango Comments Change Log

### 0.3.0
Added placeholder and minor formatting improvements.

### 0.2
Attempting better post-comment redirecting

### 0.1.11
Settling on authenticated users only.

### 0.1.10
Fixed inconsistent fieldname on form

### 0.1.9
Still more evil imports

### 0.1.8
More evil imports

### 0.1.8
Fixed evil import

### 0.1.7
More admin changes

### 0.1.6
Define readonly fields

### 0.1.5
More migration to BaseUserContentmodel

### 0.1.4 
Admin 

### 0.1.3 
Fixed lots of migration issues

### 0.1.2 
Field name mismatch from common base

### 0.1.1 
Resolved some related name issues

### 0.1
Ported Django.contrib.comments to Tango.
