# Tango Comments

This is simply a fast and dirty port of the old django.contrib.comments app, because it was deprecated, and I wanted to use Tango's UserContent model. 

If contrib.comments worked for you, this probably would too. If not, skip it and use some other commenting solution.

Or better yet, don't have comments at all. Internet comments are horrible anyway.
